<html>
    {{-- HEAD --}}

    @include('layouts.header')
    
    {{-- HEAD --}}
    <body>
        <div>
            @foreach ($items as $item)
            <div class="container">
                <div class="col-12 row d-flex justify-content-center">
                    <div class="col-md-6 col-12 text-center">
                        <button class="btn btn-primary">Order</button>
                        <img src="{{$item->item_img}}">
                        <div class="d-flex justify-content-between">
                            <div><h3>Apt : {{$item->apt}}</h3></div>
                            <div><h3>Price : {{$item->price}}</h3></div>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div><h3>Total : {{$item->room}} m<sup>2</sup></h3></div>
                            <div><h3>Balcony : {{$item->balcony}} m<sup>2</sup></h3></div>
                        </div>
                        <div>
                            <iframe src="{{$item->infos}}" style="width:300px; height:500px;"></iframe>
                        </div>              
                    </div>
                </div>
            </div>
                
            @endforeach
            
        </div>
        @include('layouts.footer')
    </body>
</html>