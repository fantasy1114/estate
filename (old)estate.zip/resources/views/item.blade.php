
<!-- BEGIN: Head-->
@include('layouts.header')
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static  " data-open="click" data-menu="vertical-menu-modern" data-col="">

    <!-- BEGIN: Header-->
    
    @include('layouts.navbar')

    <!-- END: Header-->


    <!-- BEGIN: Main Menu-->
    @include('layouts.layout')
    <!-- END: Main Menu-->

    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            
            <div class="content-body">
                <!-- Item list start -->
                <section class="app-user-list">
                    
                    <!-- list section start -->
                    <div class="card">
                        <div class="card-datatable table-responsive pt-0">
                            <table class="data-list-table table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Photo</th>
                                        <th>Floor</th>
                                        <th>Apt</th>
                                        <th>Room</th>
                                        <th>Total</th>
                                        <th>Balcony</th>
                                        <th>Rent</th>
                                        <th>Infos</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($items as $item)
                                    <tr>
                                        <td><img src="{{$item->item_img}}" alt="item" class="product_img_size rounded"></td>
                                        <td>{{$item->floor}}</td>
                                        <td>{{$item->apt}}</td>
                                        <td>{{$item->room}}</td>
                                        <td>{{$item->total}} m<sup>2</sup></td>
                                        <td>{{$item->balcony}} m<sup>2</sup></td>
                                        <td>{{$item->rent}}</td>
                                        <td><i data-feather='file-text' style="zoom:1.2"></i> <a href="{{$item->infos}}" target="_blank" style="text-decoration: underline;">Details</a></td>
                                        <td>
                                            <button class="dropdown-item data_edit_btn d-inline w-auto rounded" data-id="{{$item->id}}" data-item_img="{{$item->item_img}}" data-floor="{{$item->floor}}" data-apt="{{$item->apt}}" data-room="{{$item->room}}" data-total="{{$item->total}}" data-balcony="{{$item->balcony}}" data-rent="{{$item->rent}}">
                                                <i data-feather='edit'></i>
                                                <span></span>
                                            </button>
                                        
                                            <button class="dropdown-item d-inline item_delete_btn w-auto rounded" data-id="{{$item->id}}">
                                                <i data-feather='delete'></i>
                                                <span></span>
                                            </button>
                                            
                                            <button class="dropdown-item d-inline item_image_show w-auto rounded" data-item_img="{{$item->item_img}}">
                                                <i data-feather='image'></i>
                                            </button>
                                        </td>
                                    
                                    </tr>
                                    @endforeach
                                                                       
                                </tbody>
                            </table>
                        </div>
                        <!-- Modal to add new Data starts-->
                        <div class="modal modal-slide-in new-data-modal fade" id="modals-slide-in">
                            <div class="modal-dialog">
                                <form class="add-new-data modal-content pt-0">
                                    {{csrf_field()}}
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-label="Close">×</button>
                                    <div class="modal-header mb-1">
                                        <h5 class="modal-title" id="exampleModalLabel">Item</h5>
                                    </div>
                                    <div class="modal-body flex-grow-1">
                                        <div class="form-group">
                                            <label class="form-label" for="photo">Photo</label>
                                            <!-- header media -->
                                                <div class="media">
                                                    <a href="javascript:void(0);" class="mr-25">
                                                        <img src="#" id="item-upload-img" class="rounded mr-50" alt="image" height="80" width="80" />
                                                    </a>
                                                    <!-- upload and reset button -->
                                                    <div class="media-body mt-75 ml-1">
                                                        <label for="item-upload" class="btn btn-sm btn-primary mb-75 mr-75">Upload</label>
                                                        <input type="file" id="item-upload" name="item-upload" hidden accept="image/*" />
                                                    </div>
                                                    <!--/ upload and reset button -->
                                                </div>
                                            <!--/ header media -->
                                            
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="item_floor">Floor</label>
                                            <input type="text" class="form-control dt-full-name" id="item_floor"
                                                placeholder="1" name="item_floor" aria-label="item_floor"
                                                aria-describedby="item_floor" />
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="item_apt">Apt</label>
                                            <input type="text" class="form-control dt-full-name" id="item_apt"
                                                placeholder="A 0.1" name="item_apt" aria-label="item_apt"
                                                aria-describedby="item_apt" />
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="item_room">Room</label>
                                            <input type="number" class="form-control dt-full-name" id="item_room"
                                                placeholder="1.5" name="item_room" aria-label="item_room"
                                                aria-describedby="item_room" step="0.01" />
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="item_total">Total WF</label>
                                            <input type="number" class="form-control dt-full-name" id="item_total"
                                                placeholder="36.7 m2" name="item_total" aria-label="item_total"
                                                aria-describedby="item_total" step="0.01"/>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="item_balcony">Balcony</label>
                                            <input type="number" class="form-control dt-full-name" id="item_balcony"
                                                placeholder="8.1 m2" name="item_balcony" aria-label="item_balcony"
                                                aria-describedby="item_balcony" step="0.01"/>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="item_rent">Rent</label>
                                            <input type="text" class="form-control dt-full-name" id="item_rent"
                                                placeholder="rented" name="item_rent" aria-label="item_rent"
                                                aria-describedby="item_rent" />
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="infos">Infos</label>
                                            <!-- header media -->
                                                <div class="media">
                                                    <input type="file" id="item-upload-pdf" name="item-upload-pdf" accept=".pdf" />
                                                </div>
                                            <!--/ header media -->
                                            
                                        </div>
                                        <input type="text" value="{{str_replace('itempage/', '', Request::path())}}" name="product_id" hidden>
                                        
                                        
                                        <button type="submit" class="btn btn-primary mr-1 data-submit">Submit</button>
                                        <button type="reset" class="btn btn-outline-secondary"
                                            data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Modal to add new Data Ends-->

                        <!-- Modal to update  Data starts-->
                        <div class="modal modal-slide-in edit-data-modal fade" id="modals-slide-in">
                            <div class="modal-dialog">
                                <form class="edit-data-form modal-content pt-0">
                                    {{csrf_field()}}
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-label="Close">×</button>
                                    <div class="modal-header mb-1">
                                        <h5 class="modal-title">Update Item</h5>
                                    </div>
                                    <div class="modal-body flex-grow-1">
                                        <div class="form-group">
                                            <label class="form-label" for="photo">Photo</label>
                                            <!-- header media -->
                                                <div class="media">
                                                    <a href="javascript:void(0);" class="mr-25">
                                                        <img src="#" id="uitem-upload-img" class="rounded mr-50" alt="image" height="80" width="80" />
                                                    </a>
                                                    <!-- upload and reset button -->
                                                    <div class="media-body mt-75 ml-1">
                                                        <label for="uitem-upload" class="btn btn-sm btn-primary mb-75 mr-75">Upload</label>
                                                        <input type="file" id="uitem-upload" name="uitem-upload" hidden accept="image/*" />
                                                    </div>
                                                    <!--/ upload and reset button -->
                                                </div>
                                            <!--/ header media -->
                                            
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="uitem_floor">Floor</label>
                                            <input type="text" class="form-control dt-full-name" id="uitem_floor"
                                                placeholder="1" name="uitem_floor" aria-label="uitem_floor"
                                                aria-describedby="uitem_floor" />
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="uitem_apt">Apt</label>
                                            <input type="text" class="form-control dt-full-name" id="uitem_apt"
                                                placeholder="A 0.1" name="uitem_apt" aria-label="uitem_apt"
                                                aria-describedby="uitem_apt" />
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="uitem_room">Room</label>
                                            <input type="text" class="form-control dt-full-name" id="uitem_room"
                                                placeholder="1.5" name="uitem_room" aria-label="uitem_room"
                                                aria-describedby="uitem_room" />
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="uitem_total">Total WF</label>
                                            <input type="text" class="form-control dt-full-name" id="uitem_total"
                                                placeholder="36.7 m2" name="uitem_total" aria-label="uitem_total"
                                                aria-describedby="uitem_total" />
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="uitem_balcony">Balcony</label>
                                            <input type="text" class="form-control dt-full-name" id="uitem_balcony"
                                                placeholder="8.1 m2" name="uitem_balcony" aria-label="uitem_balcony"
                                                aria-describedby="uitem_balcony" />
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="uitem_rent">Rent</label>
                                            <input type="text" class="form-control dt-full-name" id="uitem_rent"
                                                placeholder="rented" name="uitem_rent" aria-label="uitem_rent"
                                                aria-describedby="uitem_rent" />
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="infos">Infos</label>
                                            <!-- header media -->
                                                <div class="media">
                                                    <input type="file" id="uitem-upload-pdf" name="uitem-upload-pdf" accept=".pdf" />
                                                </div>
                                            <!--/ header media -->
                                        </div>

                                        <input type="text" value="{{str_replace('itempage/', '', Request::path())}}" name="product_id" hidden>
                                        
                                        <button type="submit" class="btn btn-primary mr-1 data-submit">Submit</button>
                                        <button type="reset" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Modal to update  Data Ends-->

                        <!-- Modal -->
                        <div class="modal fade" id="item__image__show__modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 75%;">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalCenterTitle">Photo</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <img src="#" class="modal__image__show">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal END -->
                    </div>
                    
                </section>
                <!-- Item list ends -->
            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    @include('layouts.footer')

    <!-- BEGIN: Page JS-->
    <script src="{{asset('app-assets/js/scripts/tables/estate-item.js')}}"></script>
    <!-- END: Page JS-->
    
    <script>
        $(function() {
            var itemUploadImg = $('#item-upload-img'),
                itemUploadBtn = $('#item-upload'),
                uitemUploadImg = $('#uitem-upload-img'),
                uitemUploadBtn = $('#uitem-upload')
            if (itemUploadBtn) {
                itemUploadBtn.on('change', function (e) {
                var reader = new FileReader(),
                    files = e.target.files;
                reader.onload = function () {
                    if (itemUploadImg) {
                    itemUploadImg.attr('src', reader.result);
                    }
                };
                reader.readAsDataURL(files[0]);
                });
            }
            if (uitemUploadBtn) {
                uitemUploadBtn.on('change', function (e) {
                var reader = new FileReader(),
                    files = e.target.files;
                reader.onload = function () {
                    if (uitemUploadImg) {
                    uitemUploadImg.attr('src', reader.result);
                    }
                };
                reader.readAsDataURL(files[0]);
                });
            }
            // EDIT

            $(document).on("click", ".data_edit_btn", function()  {
                var id = $(this).data('id');
                var url = '/item-update/' + id;
                $("#uitem-upload-img").attr('src', $(this).data('item_img'));
                $("#uitem_floor").val($(this).data('floor'));
                $("#uitem_apt").val($(this).data('apt'));
                $("#uitem_room").val($(this).data('room'));
                $("#uitem_total").val($(this).data('total'));
                $("#uitem_balcony").val($(this).data('balcony'));
                $("#uitem_rent").val($(this).data('rent'));

                $(".edit-data-modal").modal('show');

                $('.edit-data-form').on("submit", function(e) {
                    var formData = new FormData(this);
                    e.preventDefault();
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'post',
                        url: url,
                        cache:false,
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            if(data['success']){
                                window.location.reload();
                            }
                            else{
                                console.log('error');
                            }
                        }
                    })
                });
            });

            $(document).on("click", ".item_image_show", function() {
                $(".modal__image__show").attr('src', $(this).data('item_img'));
                $("#item__image__show__modal").modal('show');
            });
           
        });
    </script>
</body>
<!-- END: Body-->

</html>