<html>

<head>
  @include('layouts.header')

    <!-- BEGIN STYLE CSS -->
    <style>
        /* loaded image */
        .loaded_img{
            width: 100%;
            height: auto;
        }

        /* Table Edit */
        .schema_table{
            height: 420px;
            overflow: auto;
            margin-bottom: 20px;
        }
        .schema_table tbody tr{
            cursor: pointer;
        }
        table tr:hover{
            background-color: #F1EDE9;
        }
        td span{
            text-decoration: underline;
        }
        td a{
            color: #9E866E;
        }
        td a:hover{
            text-decoration: none;
            color: #9E866E;
        }
        td span:hover{
            text-decoration: none;
            color: #000;
        }
    </style>
    <!-- END STYLE CSS -->
</head>

<body>
    <div class="col-12">
        <div class="container">

            <!-- Loaded image -->
            @foreach ($products as $product)
                <img src="{{$product->product_img}}" class="loaded_img" id="loaded_img" data-over="{{$product->product_img}}">
            @endforeach
            

            <div class="schema_table">
                <table class="w-100 table">
                    <thead>
                        <tr>
                            <th>Floor</th>
                            <th>Apt</th>
                            <th>Room</th>
                            <th>Total WF</th>
                            <th>Balcony</th>
                            <th>Rent</th>
                            <th>Infos</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($items as $item)
                            <tr data-over="{{$item->item_img}}" class="tr_change">
                                <td>{{$item->floor}}</td>
                                <td>{{$item->apt}}</td>
                                <td>{{$item->room}} m<sup>2</sup></td>
                                <td>{{$item->balcony}} m<sup>2</sup></td>
                                <td>{{$item->total}}</td>
                                <td>{{$item->rent}}</td>
                                <td><a href="{{$item->infos}}" target="_blank"><i class="fa fa-file-text-o"></i> <span>Details</span></a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- BEGIN JS IMPORT -->
    @include('layouts.footer')
    <!-- END JS IMPORT -->

    <script>
        
        $('.tr_change').on("mouseover", function (e){
            var img_name = $(this).data("over");
            $("#loaded_img").attr("src", img_name);
        });
        $(".tr_change").on('mouseleave', function() {
            var img_name = $('#loaded_img').data("over");
            $("#loaded_img").attr("src", img_name);
        });
    </script>
</body>

</html>