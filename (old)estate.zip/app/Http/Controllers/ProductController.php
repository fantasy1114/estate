<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{

    public function index()
    {
        $products = DB::table('products')->where('owner', Auth::user()->id)->get();
        return view('product')->with('products', $products);
    }

    public function create(Request $request)
    {
        $filename = $request->file('product-upload')->getClientOriginalName();
        $owner = Auth::user()->id;
        DB::table('products')->insert([
            'product_name' => $request->product_name,
            'owner' => $owner,
        ]);
        $id = DB::getPdo()->lastInsertId();
        if ($request->file('product-upload')) {
            $imagePath = $request->file('product-upload');
            $imagenameget = str_contains($filename, '.svg') ? $id . '.svg' : $id . '.png';
            $imagePath->move(public_path('/app-assets/uploads/products/' . $owner), $imagenameget);
        }
        DB::table('products')->where('id', $id)->update([
            'product_img' => '/app-assets/uploads/products/' . $owner . '/' . $imagenameget,
        ]);

        return response()->json(['success' => true]);
    }

    public function update(Request $request, $id)
    {
        
        $default_values = DB::table('products')->where('id', $id)->get();
        foreach ($default_values as $default_value) {
            $owner = $default_value->owner;
        }
        
        if ($request->file('uproduct-upload')) {
            $filename = $request->file('uproduct-upload')->getClientOriginalName();
            $imagenameget = str_contains($filename, '.svg') ? $id . '.svg' : $id . '.png';
            $imagePath = $request->file('uproduct-upload');
            $imagePath->move(public_path('/app-assets/uploads/products/' . $owner), $imagenameget);

            DB::table('products')->where('id', $id)->update([
                'product_name' => $request->uproduct_name,
                'product_img' => '/app-assets/uploads/products/' . $owner . '/' . $imagenameget,
            ]);

            return response()->json(['success' => true]);
        }
        else{
            DB::table('products')->where('id', $id)->update([
                'product_name' => $request->uproduct_name
            ]);

            return response()->json(['success' => true]);
        }
          
    }

    public function delete($id)
    {
        $products = DB::table('products')->where('id', $id)->get();
        foreach($products as $product){
            unlink('.'.$product->product_img);
        }
        DB::table('products')->where('id', $id)->delete();
        return response()->json(['success'=>true]);
    }

    public function show($id)
    {
        $products = DB::table('products')->where('id', $id)->get();
        $items = DB::table('items')->where('product_id', $id)->get();
        return view('front.dashboard')->with('products', $products)->with(            'items', $items);
    }

}
